/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./HideSectionPCF/index.ts":
/*!*********************************!*\
  !*** ./HideSectionPCF/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   HideSectionPCF: () => (/* binding */ HideSectionPCF)\n/* harmony export */ });\nclass HideSectionPCF {\n  constructor() {\n    this.sectionName = \"\";\n    this.isVisible = true;\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\n   */\n  init(context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this.myContext = context;\n    this.myNotifyOutputChanged = notifyOutputChanged;\n    this.myContainer = container;\n    this.sectionName = context.parameters.sectionName.raw || \"\";\n    this.isVisible = context.parameters.toggleSection.raw === true;\n    this.toggleButton = document.createElement(\"button\");\n    this.toggleButton.className = \"toggle-arrrow\"; //this.isVisible ? \"Collapse 🔽\" : \"Expand ▶️\";\n    this.toggleButton.style.border = \"none\";\n    this.toggleButton.style.background = \"transparent\";\n    this.toggleButton.style.cursor = \"pointer\";\n    this.toggleButton.onclick = () => this.onToggleClicked();\n    this.myContainer.appendChild(this.toggleButton);\n    this.rendor();\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   */\n  updateView(context) {\n    // Add code to update control view\n    var _a;\n    this.myContext = context;\n    var newToggle = (_a = context.parameters.toggleSection.raw) !== null && _a !== void 0 ? _a : true;\n    if (newToggle !== this.isVisible) {\n      this.isVisible = newToggle;\n      this.rendor();\n    }\n  }\n  onToggleClicked() {\n    this.isVisible = !this.isVisible;\n    this.toggleSection(this.isVisible);\n    this.rendor();\n    this.myContext.parameters.toggleSection.raw = this.isVisible;\n    this.myNotifyOutputChanged();\n  }\n  rendor() {\n    this.toggleButton.innerText = this.isVisible ? \"Collapse 🔽\" : \"Expand ▶️\";\n    this.toggleSection(this.isVisible);\n  }\n  toggleSection(show) {\n    // eslint-disable-next-line @typescript-eslint/no-explicit-any\n    var formContext = this.myContext.mode.context._formContext;\n    if (formContext && this.sectionName) {\n      var tabSections = formContext.ui.tabs.get();\n      for (var tab of tabSections) {\n        var section = tab.sections.get(this.sectionName);\n        if (section) {\n          section.setVisible(show);\n          break;\n        }\n      }\n    }\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      toggleSection: this.isVisible\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./HideSectionPCF/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./HideSectionPCF/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SectionPCF.HideSectionPCF', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.HideSectionPCF);
} else {
	var SectionPCF = SectionPCF || {};
	SectionPCF.HideSectionPCF = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.HideSectionPCF;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}